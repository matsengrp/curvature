These files contain the information used to make the plots in Figure 5, 6a, and 6b.

The file names specify the degrees for T1 and T2, respectively.
The column headings should be self-explanatory, but if not, please contact the authors.
